#ifndef __UTIL_H
#define __UTIL_H
#include "lcd.h"

void KEY0_to_skip(void);

#endif
