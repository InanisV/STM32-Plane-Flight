#ifndef __UTIL_H
#define __UTIL_H
#include "sys.h"  
#include "delay.h"
#include "key.h"
#include "lcd.h"

void KEY0_to_skip(void);

#endif
