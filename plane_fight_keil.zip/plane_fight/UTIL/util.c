#include "util.h"


void KEY0_to_skip(void){
	while(1){
		if(KEY_Scan(0) == KEY0_PRES){
		  break;
		}
		else{
			delay_ms(10);
		}
	}
}

